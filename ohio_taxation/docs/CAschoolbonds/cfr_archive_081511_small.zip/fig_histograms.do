capture log close
log using fig_histograms.log, text replace

#delimit;
clear;
set mem 32m;
set scheme s2mono;

*use ../houseprices/fromfernando/referenda_newleaids_capital;
use referenda_newleaids_capital;
 rename year yearref;
 *note: we are replacing calendar year with schoolyear;
  clonevar year=yearref;
  replace yearref = yearref - 1 if month<5;
 *change req threshold and type in one election, look at :\\coauthor\referenda_graphing_RDD.do for details;
  replace req="M" if newleaid=="0615180" & yearref==1992;
  replace election_type="Other" if newleaid=="0615180" & yearref==1992;

 *Select sample;
  *Keep only measures since 1995;
   *keep if yearref>=1995;
  *Keep only measures since 1987;
   keep if yearref>=1987;
  *Keep only GO Bonds and parcel taxes;
   keep if election_type== "GO Bond"  | election_type=="Parcel Tax";
   gen gobond=(election_type=="GO Bond");
   gen parcel_cap=(capitaloutlays=="Y")*(gobond==0);
  *Identify measures where percent, passfail, and req dont all match;
   gen mv=percent-req_num;
   gen badobs=(mv>=0 & mv<. & passfail=="F");
   replace badobs=1 if mv<0 & passfail=="P";
   replace badobs=1 if mv==.;
   count if badobs==1 & percent<.;
   assert r(N)==1;
   count if badobs==1 & percent==.;
   replace percent=. if badobs==1;
   label var mv "voteshare-based MARGIN of VICTORY";
  *If there are multiple measures that meet these criteria, keep winning over losing measures
  *and then keep only the highest vote share.  Break ties by (1) lowest requirement (2) GO over parcel.;
   gen win=(passfail=="P");
   gsort newleaid yearref badobs -gobond -win -percent req_num ;
   by newleaid yearref: gen numelec=_N;
   by newleaid yearref: gen numbad=sum(badobs);
   by newleaid yearref: replace badobs=(numbad[_N]>0);
   by newleaid yearref: keep if _n==1;
   label var numelec "# of GO/parcel elecs in same year";
   gen fakewin=(percent>=66.7) if percent<. & req_num<=56;
   replace fakewin=(percent>=55) if percent<. & req_num>=66 & req_num<.;
   assert req_num<=56 | req_num>=66;
   label var fakewin "Indicator for pass at counterfactual threshold";
 *We only need a few variables;
  keep newleaid yearref percent win req_num numelec gobond parcel_cap fakewin;
  rename req_num req;

*Keep on GO Bonds;
keep if gobond==1;

gen percent_cens=min(max(percent, 40.5), 89.5);

twoway histogram percent_cens if req<60, width(3.3333333) start(38.3333333) xline(55)
          xtitle("Vote share in favor")
          title("55% threshold (N=382)") name(panel55, replace) nodraw freq;
twoway histogram percent_cens if req>60, width(3.3333333) start(40) xline(66.666667)
          xtitle("Vote share in favor")
          title("66.7% threshold (N=848)") name(panel67, replace) nodraw freq;
graph combine panel55 panel67, xcommon ycommon
      title("Distribution of measures by vote share and threshold")
      saving(fig1.gph, replace);
graph combine panel55 panel67, xcommon ycommon
      saving(fig1_notitle.gph, replace);

log close;
